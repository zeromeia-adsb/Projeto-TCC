from distutils.log import info
from sre_constants import SUCCESS
from flask import Flask, flash, render_template, request, url_for, redirect
from flask_sqlalchemy import SQLAlchemy

from sqlalchemy import Table, String, Column, Integer, ForeignKey, Date, create_engine
from sqlalchemy.orm import relationship, sessionmaker
from sqlalchemy.ext.declarative import declarative_base

app = Flask(__name__, template_folder='templates')

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///clientes.db'

db = SQLAlchemy(app)


# Classe do Veículo
class Veiculo(db.Model):
    __tablename__ = 'veiculos'
    id = db.Column('ID', db.Integer, primary_key=True, autoincrement=True)
    marca = db.Column('Marca', db.String(150), nullable=False)
    modelo = db.Column('Modelo', db.String(150), nullable=False)
    cor = db.Column('Cor', db.String(150), nullable=False)
    placa = db.Column('Placa', db.String(150), nullable=False)
    cliente_id = db.Column(db.Integer, db.ForeignKey('clientes.ID'))
    cliente = relationship('Cliente')

    def __init__(self, marca, modelo, cor, placa, cliente):
        self.marca = marca
        self.modelo = modelo
        self.cor = cor
        self.placa = placa
        self.cliente = cliente


# Classe do Cliente
class Cliente(db.Model):
    __tablename__ = 'clientes'
    id = db.Column('ID', db.Integer, primary_key=True, autoincrement=True)
    nome = db.Column('Nome', db.String(150), nullable=False)
    email = db.Column('Email', db.String(150), nullable=False)
    telefone = db.Column('Telefone', db.String(150), nullable=False)
    celular = db.Column('Celular', db.String(150), nullable=False)
    veiculos = relationship(Veiculo, backref="clientes")

    def __init__(self, nome, email, telefone, celular):
        self.nome = nome
        self.email = email
        self.telefone = telefone
        self.celular = celular


# Classe do Funcionário
class Funcionario(db.Model):
    __tablename__ = 'funcionarios'
    id = db.Column('ID', db.Integer, primary_key=True, autoincrement=True)
    nome = db.Column('Nome', db.String(150), nullable=False)
    email = db.Column('Email', db.String(150), nullable=False)
    telefone = db.Column('Telefone', db.String(150), nullable=False)
    celular = db.Column('Celular', db.String(150), nullable=False)
    dataAniversario = db.Column('Data Aniversário', db.String(10), nullable=False)
    dataContrato = db.Column('Data Contrato', db.String(10), nullable=False)
    funcao = db.Column('Função', db.String(150), nullable=False)

    def __init__(self, nome, email, telefone, celular, dataAniversario, dataContrato, funcao):
        self.nome = nome
        self.email = email
        self.telefone = telefone
        self.celular = celular
        self.dataAniversario = dataAniversario
        self.dataContrato = dataContrato
        self.funcao = funcao


@app.route('/')
def index():
    cliente = Cliente.query.all()
    return render_template("index.html", clientes = cliente)

@app.route('/cadastrar_clientes', methods=['GET', 'POST'])
def adiciona_cliente():
    if request.method == 'POST':
        cliente = Cliente(request.form['nome'], request.form['email'], request.form['telefone'], request.form['celular'])
        veiculo = Veiculo(request.form['marca'], request.form['modelo'], request.form['cor'], request.form['placa'], cliente)
        if cliente.nome == '' or cliente.celular == '':
            mensagem = 'Não deixe campos obrigatórios em branco!'
            return render_template('cadastrar_clientes.html', mensagem = mensagem)
        elif veiculo.marca == '' or veiculo.modelo == '' or veiculo.cor == '' or veiculo.placa == '':
            mensagem = 'Não deixe campos obrigatórios em branco!'
            return render_template('cadastrar_clientes.html', mensagem = mensagem)
        else:
            db.session.add(cliente)
            db.session.add(veiculo)
            db.session.commit()
            mensagem_sucesso = f'{cliente.nome.upper()} foi cadastrado(a) com SUCESSO!'
            return render_template('cadastrar_clientes.html', mensagem_ok = mensagem_sucesso)
    return render_template('cadastrar_clientes.html')

@app.route('/consultar_clientes', methods=['GET', 'POST'])
def consulta_cliente():   
    if request.method == 'POST':
        return redirect(url_for('resultado_cliente'))
    return render_template("consultar_clientes.html")

@app.route('/resultado_clientes', methods=['GET', 'POST'])
def resultado_cliente():
    cliente = Cliente.query.all()
    veiculo = Veiculo.query.all()
    mensagem_info = 'Pesquise por informações do cliente ou deixe em branco para retornar todos os resultados.'
    if request.method == 'POST':
        opcao = request.form['opcao_cliente'] # pega a informação das opções
        campo = request.form['campo_cliente'] # pega a informação do que foi preenchido
        return render_template("resultado_clientes.html", clientes = cliente, veiculos = veiculo, opcao_cliente = opcao, campo_cliente = campo)
    return render_template("resultado_clientes.html", mensagem_info = mensagem_info)

@app.route('/editar_clientes/<int:id>', methods=['GET', 'POST'])
def edita_cliente(id):
    cliente = Cliente.query.get(id)
    veiculo = Veiculo.query.all()
    if request.method == 'POST':
        cliente.nome = request.form['nome'] # salva com as novas informações inseridas
        cliente.email = request.form['email']
        cliente.telefone = request.form['telefone']
        cliente.celular = request.form['celular']
        db.session.commit()
        mensagem = f"{cliente.nome} foi editado(a) com sucesso! Clique novamente em pesquisar para ver os registros!" # validação
        return render_template("resultado_clientes.html", mensagem_editar = mensagem, veiculos = veiculo)
    return render_template('editar_clientes.html', cliente = cliente, veiculos = veiculo)

@app.route('/deletar_clientes/<int:id>')
def deleta_cliente(id):
    cliente = Cliente.query.get(id)
    db.session.delete(cliente) # deleta os dados daquele cliente 
    db.session.commit()
    mensagem = f"{cliente.nome} foi DELETADO(A)! Clique novamente em pesquisar para ver os registros!" # validação
    return redirect(f'')
    # return render_template("resultado_clientes.html", mensagem_deletar = mensagem)

@app.route('/info_clientes/<int:id>')
def info_cliente(id):
    cliente = Cliente.query.get(id)
    veiculo = Veiculo.query.all()
    return render_template('info_clientes.html', cliente = cliente, veiculos = veiculo)

@app.route('/cadastrar_veiculo', methods=['GET', 'POST'])
def cadastro_veiculo():
    cliente = Cliente.query.all()
    mensagem_info = 'Pesquise por informações do cliente ou deixe em branco para retornar todos os resultados.'
    if request.method == 'POST':
        opcao = request.form['opcao_cliente'] # pega a informação das opções
        campo = request.form['campo_cliente'] # pega a informação do que foi preenchido
        return render_template("cadastrar_veiculo.html", clientes = cliente, opcao_cliente = opcao, campo_cliente = campo)
    return render_template("cadastrar_veiculo.html", mensagem_info = mensagem_info)

@app.route('/veiculos/<int:id>', methods=['GET', 'POST'])
def adiciona_veiculo(id):
    cliente = Cliente.query.get(id)
    veiculo_cliente = Veiculo.query.all()
    if request.method == 'POST':
        veiculo = Veiculo(request.form['marca'], request.form['modelo'], request.form['cor'], request.form['placa'], cliente)
        if veiculo.marca == '' or veiculo.modelo == '' or veiculo.cor == '' or veiculo.placa == '':
            mensagem = 'Não deixe campos obrigatórios em branco!'
            return render_template('veiculos.html', cliente = cliente, veiculos = veiculo_cliente, mensagem = mensagem)
        else:
            db.session.add(veiculo)
            db.session.commit()
            mensagem_sucesso = f'Veículo cadastrado com SUCESSO!'
            flash(mensagem_sucesso,'info')
            return redirect(f'/veiculos/{cliente.id}')
            #return render_template('veiculos.html', cliente = cliente, veiculos = veiculo_cliente, mensagem_sucesso = mensagem_sucesso)
    return render_template('veiculos.html', cliente = cliente, veiculos = veiculo_cliente)

@app.route('/editar_veiculo/<int:id>', methods=['GET', 'POST'])
def edita_veiculo(id):
    veiculo = Veiculo.query.get(id)
    id_cliente = veiculo.cliente_id
    cliente = Cliente.query.get(id_cliente)
    if request.method == 'POST':
        veiculo.marca = request.form['marca'] # salva com as novas informações inseridas
        veiculo.modelo = request.form['modelo']
        veiculo.cor = request.form['cor']
        veiculo.placa = request.form['placa']
        db.session.commit()
        mensagem_sucesso = f'Veículo editado com SUCESSO!'
        return render_template("veiculos.html", mensagem_sucesso = mensagem_sucesso, cliente = cliente, veiculo = veiculo)
    return render_template("editar_veiculo.html", cliente = cliente, veiculo = veiculo)

@app.route('/deletar_veiculo/<int:id>')
def deleta_veiculo(id):
    veiculo = Veiculo.query.get(id)
    id_cliente = veiculo.cliente_id
    cliente = Cliente.query.get(id_cliente)
    db.session.delete(veiculo)
    db.session.commit()
    mensagem = f"Veículo placa {veiculo.placa} foi DELETADO(A)!" # validação
    flash(mensagem,'error')
    return redirect(f'/veiculos/{cliente.id}')
    # return render_template("veiculos.html", cliente = cliente, mensagem_deletar = mensagem) 

@app.route('/cadastrar_funcionario', methods=['GET', 'POST'])
def adiciona_funcionario():
    if request.method == 'POST':
        funcionario = Funcionario(request.form['nome'], request.form['email'], request.form['telefone'], request.form['celular'], request.form['dataAniversario'], request.form['dataContrato'], request.form['funcao'])
        if funcionario.nome == '' or funcionario.celular == '' or funcionario.dataAniversario == '' or funcionario.dataContrato == '' or funcionario.funcao == '':
            mensagem = 'Não deixe campos obrigatórios em branco!'
            return render_template('cadastrar_funcionario.html', mensagem = mensagem)
        else:
            db.session.add(funcionario)
            db.session.commit()
            mensagem_sucesso = f'{funcionario.nome.upper()} foi cadastrado(a) com SUCESSO!'
            return render_template('cadastrar_funcionario.html', mensagem_ok = mensagem_sucesso)
    return render_template('cadastrar_funcionario.html')

if __name__ == '__main__':
    db.create_all()
    app.secret_key= "superchavesecreta"
    app.run(debug=True)